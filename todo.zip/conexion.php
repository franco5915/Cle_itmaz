<?php
  $conn = new mysqli('localhost','id11777965_super','12345678','id11777965_cle_itmaz');
  if($conn->connect_error){
    echo $error->$conn->connect_error;
  }
  $conn->set_charset('utf8');
 ?>