<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	
	<link rel="stylesheet" type="text/css" href="css/tabla2.css">
    <link rel="stylesheet" type="text/css" href="css/materialize.css">
	<title>Log in</title>
</head>
<body>
<nav>
		<div class="nav-wrapper">
            <!--<a href="#" class="brand-logo"><img src="imagenes/62540.jpg" alt=""></a>-->
            <ul id="nav-mobile" class="right hide-on-med-and-down">
			<a href="index.php">Regresar a inicio </a>

            </ul>
        </div>
</nav>
		
    	<div id="content" align = "center" background-color: #09017a>
		<h1>Registro de Usuarios</h1>
		<form action="saveUser.php" method="POST">
	        <table border="1">
		        <tr>
		            <td><label>No.Control</label></td>
		            <td><input type="text" name="noControl" placeholder="noControl" minlength="8" maxlength="9" onkeypress="return (event.charCode >= 48 && event.charCode <= 57)"  required  /></td>
				</tr>
				<tr>
		            <td><label>Apellidos</label></td>	
		            <td><input type="text" name="apellido" placeholder="Apellido" onkeypress="return (event.charCode >= 65 && event.charCode <= 90 || event.charCode >= 97 && event.charCode <= 122 || event.charCode == 32 )" min="1" maxlength="50" required/></td>
		        </tr>
		        <tr>
		            <td><label>Nombre</label></td>
		            <td><input type="text" name="nombre" placeholder="Nombre" onkeypress="return (event.charCode >= 65 && event.charCode <= 90 || event.charCode >= 97 && event.charCode <= 122 || event.charCode == 32 )" min="1" maxlength="50" required/></td>
				</tr>
				<tr>
		            <td><label>Carrera</label></td>
		            <td>
						<select name="carrera" required>
							<option>ISC</option>
							<option>IME</option>
							<option>INA</option>
							<option>IBQ</option>
							<option>IPE</option>
							<option>IEZ</option>
							<option>IGE</option>
						</select>
					</td>
		        </tr>
		        <tr>
		            <td><label>Correo electronico</label></td>
		            <td><input type="email" name="emailuser" placeholder="example@mail.com" required/></td>
		        </tr>
		        <tr>
		            <td><label>Contrase&ntilde;a</label></td>
		            <td><input type="password" name="pass" placeholder="**********" min minlength="8"  required/></td>
		        </tr>
		        <tr>
		            <td><label>Repetir Contrase&ntilde;a</label></td>
		            <td><input type="password" name="rpass" placeholder="**********" minlength="8"  required/></td>
		        </tr>
		        <tr>
				
		            <td><label><input type="submit" value="Registrarme"></input></label></td>
					<td><label><input type="reset" value="Limpiar campos"></input></label></td>
				</tr>
		</form>
	</div>
	
</body>
</html>