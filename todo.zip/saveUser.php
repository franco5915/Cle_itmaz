<?php 
    $noControl = $_POST['noControl'];
    $apellido = $_POST['apellido'];
    $nombre = $_POST['nombre'];
    $carrera = $_POST['carrera'];
    $email = $_POST['emailuser'];
    $password = $_POST['pass'];
    $password2 = $_POST['rpass'];
    $password = md5($password);
    $password2 = md5($password2);

    if( $password == $password2){
        include_once('conexion.php');
        try {
          $stmt = $conn->prepare("INSERT INTO alumnos (noControl,alumnoNombre,alumnoApellido,alumnoCorreo,alumnoContraseña,Carrera) VALUES (?,?,?,?,?,?) ");
          $stmt->bind_param('isssss', $noControl, $nombre, $apellido, $email, $password, $carrera);
          $stmt->execute();
          if($stmt->affected_rows > 0){
            echo '<script type="text/javascript">
            alert("El usuario ha sido registrado correctamente, No. Control : '.$noControl.'");
            window.location.href="/";
           </script>';
          }
          $stmt->close();
          $conn->close();
        } catch (Exception $e) {
          echo $e->getMessage();
          echo $e->getLine();
        }
    }else{
        echo '<script type="text/javascript">
        alert("Te has equivocado al repetir la contraseña");
        window.location.href="http://cleitmaz.net:8080/formulario.php";
       </script>';
    }

?>