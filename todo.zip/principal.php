<?php
include("conexion.php");

$con = conectar();
echo "se realizó la conexión"
?>