<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/estiloIndex.css">
	<title>CLE ITMAZ</title>
</head>

<body>
    <ul  class="img">
        <li><img src="imagenes/62540.jpg" alt=""></li>
    </ul>
    <ul class ="menu">
        <li><a href="index.php">  Regresar    </a></li>
    </ul>
    <b> Aquí iran los requisitos que se tienen para las inscripciones, así como información sobre
        los documentos correspondientes </b>

</body>
</html>